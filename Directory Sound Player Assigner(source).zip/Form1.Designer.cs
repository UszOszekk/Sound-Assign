﻿
namespace Directory_Sound_Player_Assigner
{
    partial class Selector
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Selector));
            this.select1 = new System.Windows.Forms.Button();
            this.labelpath1 = new System.Windows.Forms.Label();
            this.play1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.labelpath2 = new System.Windows.Forms.Label();
            this.select2 = new System.Windows.Forms.Button();
            this.play2 = new System.Windows.Forms.Button();
            this.labelpath3 = new System.Windows.Forms.Label();
            this.select3 = new System.Windows.Forms.Button();
            this.play3 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // select1
            // 
            this.select1.BackColor = System.Drawing.Color.Red;
            this.select1.Location = new System.Drawing.Point(218, 24);
            this.select1.Name = "select1";
            this.select1.Size = new System.Drawing.Size(75, 23);
            this.select1.TabIndex = 0;
            this.select1.Text = "select";
            this.select1.UseVisualStyleBackColor = false;
            this.select1.Click += new System.EventHandler(this.button1_Click);
            // 
            // labelpath1
            // 
            this.labelpath1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelpath1.Cursor = System.Windows.Forms.Cursors.No;
            this.labelpath1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labelpath1.Location = new System.Drawing.Point(12, 24);
            this.labelpath1.MaximumSize = new System.Drawing.Size(1000, 1000);
            this.labelpath1.MinimumSize = new System.Drawing.Size(200, 23);
            this.labelpath1.Name = "labelpath1";
            this.labelpath1.Size = new System.Drawing.Size(200, 23);
            this.labelpath1.TabIndex = 1;
            this.labelpath1.Text = "Select Path";
            this.labelpath1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // play1
            // 
            this.play1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.play1.Location = new System.Drawing.Point(299, 24);
            this.play1.Name = "play1";
            this.play1.Size = new System.Drawing.Size(25, 23);
            this.play1.TabIndex = 2;
            this.play1.Text = "♪";
            this.play1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.play1.UseVisualStyleBackColor = true;
            this.play1.Click += new System.EventHandler(this.play_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(264, 239);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 44);
            this.button2.TabIndex = 3;
            this.button2.Text = "Open 2nd window";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // labelpath2
            // 
            this.labelpath2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelpath2.Cursor = System.Windows.Forms.Cursors.No;
            this.labelpath2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labelpath2.Location = new System.Drawing.Point(12, 81);
            this.labelpath2.MaximumSize = new System.Drawing.Size(1000, 1000);
            this.labelpath2.MinimumSize = new System.Drawing.Size(200, 23);
            this.labelpath2.Name = "labelpath2";
            this.labelpath2.Size = new System.Drawing.Size(200, 23);
            this.labelpath2.TabIndex = 4;
            this.labelpath2.Text = "Select Path";
            this.labelpath2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // select2
            // 
            this.select2.BackColor = System.Drawing.Color.Red;
            this.select2.Location = new System.Drawing.Point(218, 80);
            this.select2.Name = "select2";
            this.select2.Size = new System.Drawing.Size(75, 23);
            this.select2.TabIndex = 5;
            this.select2.Text = "select";
            this.select2.UseVisualStyleBackColor = false;
            this.select2.Click += new System.EventHandler(this.select2_Click);
            // 
            // play2
            // 
            this.play2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.play2.Location = new System.Drawing.Point(299, 81);
            this.play2.Name = "play2";
            this.play2.Size = new System.Drawing.Size(25, 23);
            this.play2.TabIndex = 6;
            this.play2.Text = "♪";
            this.play2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.play2.UseVisualStyleBackColor = true;
            this.play2.Click += new System.EventHandler(this.play2_Click);
            // 
            // labelpath3
            // 
            this.labelpath3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelpath3.Cursor = System.Windows.Forms.Cursors.No;
            this.labelpath3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labelpath3.Location = new System.Drawing.Point(12, 143);
            this.labelpath3.MaximumSize = new System.Drawing.Size(1000, 1000);
            this.labelpath3.MinimumSize = new System.Drawing.Size(200, 23);
            this.labelpath3.Name = "labelpath3";
            this.labelpath3.Size = new System.Drawing.Size(200, 23);
            this.labelpath3.TabIndex = 7;
            this.labelpath3.Text = "Select Path";
            this.labelpath3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // select3
            // 
            this.select3.BackColor = System.Drawing.Color.Red;
            this.select3.Location = new System.Drawing.Point(218, 143);
            this.select3.Name = "select3";
            this.select3.Size = new System.Drawing.Size(75, 23);
            this.select3.TabIndex = 8;
            this.select3.Text = "select";
            this.select3.UseVisualStyleBackColor = false;
            this.select3.Click += new System.EventHandler(this.select3_Click);
            // 
            // play3
            // 
            this.play3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.play3.Location = new System.Drawing.Point(299, 143);
            this.play3.Name = "play3";
            this.play3.Size = new System.Drawing.Size(25, 23);
            this.play3.TabIndex = 9;
            this.play3.Text = "♪";
            this.play3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.play3.UseVisualStyleBackColor = true;
            this.play3.Click += new System.EventHandler(this.play3_Click);
            // 
            // Selector
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(351, 295);
            this.Controls.Add(this.play3);
            this.Controls.Add(this.select3);
            this.Controls.Add(this.labelpath3);
            this.Controls.Add(this.play2);
            this.Controls.Add(this.select2);
            this.Controls.Add(this.labelpath2);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.play1);
            this.Controls.Add(this.labelpath1);
            this.Controls.Add(this.select1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(367, 334);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(367, 334);
            this.Name = "Selector";
            this.Text = "Sound Assign";
            this.Load += new System.EventHandler(this.Selector_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button select1;
        private System.Windows.Forms.Label labelpath1;
        private System.Windows.Forms.Button play1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label labelpath2;
        private System.Windows.Forms.Button select2;
        private System.Windows.Forms.Button play2;
        private System.Windows.Forms.Label labelpath3;
        private System.Windows.Forms.Button select3;
        private System.Windows.Forms.Button play3;
    }
}

